import AWS from 'aws-sdk';
import csv from 'csv-parser';

const s3 = new AWS.S3();
const dynamodb = new AWS.DynamoDB.DocumentClient();

const tableName = 'Jugadores';

export const handler = async (event) => {
    const bucket = 'bucketcsvjugadores'; // Nombre del bucket
    const key = 'ligafutbolone.csv'; // Nombre del archivo CSV
    
    const params = {
        Bucket: bucket,
        Key: key
    };
    
    const s3Stream = s3.getObject(params).createReadStream();
    
    s3Stream
        .pipe(csv())
        .on('data', async (data) => {
            const params = {
                TableName: tableName,
                Item: {
                    iddeporte: data.iddeporte,
                    idequipo: data.idequipo,
                    Nombre: data.Nombre,
                    idjugador: data.idjugador,
                    idtorneo: data.idtorneo,
                    deporte: data.deporte,
                    user: data.user,
                    perfil: data.perfil,
                    posicion: data.posicion,
                    edad: parseInt(data.edad), // Se asume que la edad es un número
                    numero: parseInt(data.numero),
                    equipo: data.Equipo,
                    foto: data.foto,
                    alias: data.Alias,
                    tipocuenta: parseInt(data.tipocuenta),
                    futgoles: parseInt(data.futgoles),
                    futasisgol:parseInt( data.futasisgol),
                    futtarjetasallas: parseInt(data.futtarjetasallas),
                    futtarjetasrojas: parseInt(data.futtarjetasrojas),
                    futgoleadorsemana: parseInt(data.futgoleadorsemana),
                    beicarrerashechas: parseInt(data.beicarrerashechas),
                    beicarrerasproducid: parseInt(data.beicarrerasproducid),
                    beihr: parseInt(data.beihr),
                    beihits: parseInt(data.beihits),
                    beifly: parseInt(data.beifly),
                    beirolas: parseInt(data.beirolas),
                    beiponches: parseInt(data.beiponches),
                    mvp: parseInt(data.mvp),
                    beipitentradaslanzadas: parseInt(data.beipitentradaslanzadas),
                    beipitcarreraslimpias: parseInt(data.beipitcarreraslimpias),
                    beipithitstotales: parseInt(data.beipithitstotales),
                    beipitponchestotales: parseInt(data.beipitponchestotales),
                    beipitera: data.beipitera,
                    beipitjuegosganados: parseInt(data.beipitjuegosganados),
                    beipitjuegosperdidos: parseInt(data.beipitjuegosperdidos),
                    beiporcentajebateo: data.beiporcentajebateo,
                    clave_liga: data.clave_liga
                }
            };
            
            try {
                await dynamodb.put(params).promise();
            } catch (err) {
                console.error('Error al escribir en DynamoDB', err);
                throw err;
            }
        })
        .on('end', () => {
            console.log('Importación de CSV completada');
        });

    return 'Datos CSV importados exitosamente a DynamoDB';
};